namespace AirlineFormApp.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class Airport
    {
        public int id { get; set; }
        public string airport_symbol { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string zip { get; set; }
    }
}
