﻿
namespace AirlineFormApp.Models
{
    public class SeatingChart
    {
        public string AirplaneType { get; set; }
        public string Flight { get; set; }
        public int SeatRow { get; set; }
        public int SeatCol { get; set; }
        public int Class { get; set; }
        public string Occupied { get; set; }
        public string passengerUserId { get; set; }
    }
}