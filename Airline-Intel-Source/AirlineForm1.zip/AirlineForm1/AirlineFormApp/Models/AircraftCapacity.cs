namespace AirlineFormApp.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class AircraftCapacity
    {
        public int id { get; set; }
        public string aircraft_type { get; set; }
        public Nullable<int> number_rows { get; set; }
        public Nullable<int> number_seats { get; set; }
    }
}
