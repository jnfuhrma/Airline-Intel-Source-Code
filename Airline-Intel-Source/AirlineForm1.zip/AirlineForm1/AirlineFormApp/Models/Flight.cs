namespace AirlineFormApp.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class Flight
    {
        public string flight_number { get; set; }
        public Nullable<int> passenger { get; set; }
        public Nullable<int> seat_row { get; set; }
        public Nullable<int> seat_num { get; set; }
    }
}
