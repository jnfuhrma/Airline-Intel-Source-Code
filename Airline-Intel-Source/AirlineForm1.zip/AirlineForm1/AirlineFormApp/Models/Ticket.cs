namespace AirlineFormApp.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class Ticket
    {
        public int id { get; set; }
        public string flight_number { get; set; }
        public string passenger_last { get; set; }
        public string passenger_first { get; set; }
        public string ticket_class { get; set; }
        public decimal price { get; set; }
        public DateTime departure { get; set; }
        public DateTime arrival { get; set; }
        public string origin { get; set; }
        public string destination { get; set; }
        public string gate { get; set; }
        public  int seat_row { get; set; }
        public int seat_col { get; set; }
    }
}
