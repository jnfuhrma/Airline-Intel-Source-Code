namespace AirlineFormApp.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class FlightInformation
    {
        public int id { get; set; }
        public string flight_number { get; set; }
        public string airline { get; set; }
        public Nullable<decimal> first { get; set; }
        public Nullable<decimal> economy { get; set; }
        public string aircraft_type { get; set; }
        public Nullable<System.DateTime> boarding { get; set; }
        public Nullable<System.DateTime> arrival { get; set; }
        public Nullable<System.DateTime> departure { get; set; }
        public string destination { get; set; }
        public string origin { get; set; }
        public string Gate { get; set; }
    }
}
