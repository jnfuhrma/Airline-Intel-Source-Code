namespace AirlineFormApp.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class Passenger
    {
        public int id { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public Nullable<int> Age { get; set; }
        public string UserId { get; set; }
    }
}
