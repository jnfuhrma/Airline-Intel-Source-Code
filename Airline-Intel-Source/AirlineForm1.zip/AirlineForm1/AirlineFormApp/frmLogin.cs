﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.Configuration;
using System.Windows.Forms;
using AirlineFormApp.Helpers;
using AirlineFormApp.Models;

namespace AirlineFormApp
{
    internal partial class frmLogin : Form
    {
        delegate void DelUser(string userNamIn, string userAuthIn);
        delegate void DelRegister();

        public string dbConnString { get; set; }
        public string User { get; set; }
        public string Auth { get; set; }
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //
            Login tempLogin = new Login();
            tempLogin.UserName = this.txtUser.Text;
            tempLogin.Password = this.txtPassword.Text;
            string myConnStr;

            try
            {
                MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection();
                myConnStr = "server=127.0.0.1;uid=root;pwd=19PeggyAE47;database=airlines";
                conn.ConnectionString = myConnStr;
                conn.Open();

                //MySqlDataAdapter daLogin = new MySqlDataAdapter();
                //daLogin.SelectCommand = new MySqlCommand("select username, authority from login");
                using (MySqlCommand cmd = new MySqlCommand("get_logins", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@usernameIn", tempLogin.UserName);
                    cmd.Parameters.AddWithValue("@passwordIn", tempLogin.Password);
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            foreach (DataRow dtRow in dt.Rows)
                            {
                                User = dtRow[0].ToString();
                                Auth = dtRow[2].ToString();
                            }
                            frmMain myMain = new frmMain();
                            if (Auth == "Admin")
                            {
                                myMain.UserAuth = "Admin";
                            }
                            else
                            {
                                myMain.UserAuth = "User";
                            }
                            myMain.Show();
                            this.Hide();
                        }
                        this.lblLoginMsg.Text = "Login failed. Please try again, or Register.";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in creating MySql Connection: " + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            frmRegister myRegister = new frmRegister();
            myRegister.ShowDialog();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            Utilities util = new Utilities();
            this.dbConnString = util.getConnectionString();
        }
    }
}
