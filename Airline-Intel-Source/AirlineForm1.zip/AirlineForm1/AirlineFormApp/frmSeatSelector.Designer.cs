﻿
namespace AirlineFormApp
{
    partial class frmSeatSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkListA = new System.Windows.Forms.CheckedListBox();
            this.chkListB = new System.Windows.Forms.CheckedListBox();
            this.dgFlight = new System.Windows.Forms.DataGridView();
            this.txtLast = new System.Windows.Forms.TextBox();
            this.lblLast = new System.Windows.Forms.Label();
            this.lblFirst = new System.Windows.Forms.Label();
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSeatSelected = new System.Windows.Forms.TextBox();
            this.lblClass = new System.Windows.Forms.Label();
            this.txtClass = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.btnBuy = new System.Windows.Forms.Button();
            this.rtxtTicket = new System.Windows.Forms.RichTextBox();
            this.lblTicket = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgFlight)).BeginInit();
            this.SuspendLayout();
            // 
            // chkListA
            // 
            this.chkListA.CheckOnClick = true;
            this.chkListA.FormattingEnabled = true;
            this.chkListA.Location = new System.Drawing.Point(93, 183);
            this.chkListA.Name = "chkListA";
            this.chkListA.Size = new System.Drawing.Size(81, 199);
            this.chkListA.TabIndex = 0;
            this.chkListA.SelectedIndexChanged += new System.EventHandler(this.chkListA_SelectedIndexChanged);
            // 
            // chkListB
            // 
            this.chkListB.CheckOnClick = true;
            this.chkListB.FormattingEnabled = true;
            this.chkListB.Location = new System.Drawing.Point(233, 183);
            this.chkListB.Name = "chkListB";
            this.chkListB.Size = new System.Drawing.Size(81, 199);
            this.chkListB.TabIndex = 1;
            this.chkListB.SelectedIndexChanged += new System.EventHandler(this.chkListB_SelectedIndexChanged);
            // 
            // dgFlight
            // 
            this.dgFlight.AllowUserToAddRows = false;
            this.dgFlight.AllowUserToDeleteRows = false;
            this.dgFlight.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFlight.Location = new System.Drawing.Point(34, 33);
            this.dgFlight.Name = "dgFlight";
            this.dgFlight.ReadOnly = true;
            this.dgFlight.Size = new System.Drawing.Size(830, 70);
            this.dgFlight.TabIndex = 2;
            // 
            // txtLast
            // 
            this.txtLast.Location = new System.Drawing.Point(183, 122);
            this.txtLast.Name = "txtLast";
            this.txtLast.Size = new System.Drawing.Size(153, 20);
            this.txtLast.TabIndex = 3;
            // 
            // lblLast
            // 
            this.lblLast.AutoSize = true;
            this.lblLast.Location = new System.Drawing.Point(93, 125);
            this.lblLast.Name = "lblLast";
            this.lblLast.Size = new System.Drawing.Size(61, 13);
            this.lblLast.TabIndex = 4;
            this.lblLast.Text = "Last Name:";
            // 
            // lblFirst
            // 
            this.lblFirst.AutoSize = true;
            this.lblFirst.Location = new System.Drawing.Point(376, 128);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(57, 13);
            this.lblFirst.TabIndex = 6;
            this.lblFirst.Text = "First Name";
            // 
            // txtFirst
            // 
            this.txtFirst.Location = new System.Drawing.Point(466, 125);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.Size = new System.Drawing.Size(153, 20);
            this.txtFirst.TabIndex = 5;
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(648, 128);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(29, 13);
            this.lblAge.TabIndex = 8;
            this.lblAge.Text = "Age:";
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(683, 125);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(58, 20);
            this.txtAge.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(343, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Seat Selected:";
            // 
            // txtSeatSelected
            // 
            this.txtSeatSelected.Location = new System.Drawing.Point(346, 209);
            this.txtSeatSelected.Name = "txtSeatSelected";
            this.txtSeatSelected.Size = new System.Drawing.Size(58, 20);
            this.txtSeatSelected.TabIndex = 9;
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Location = new System.Drawing.Point(343, 248);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(32, 13);
            this.lblClass.TabIndex = 12;
            this.lblClass.Text = "Class";
            // 
            // txtClass
            // 
            this.txtClass.Location = new System.Drawing.Point(346, 264);
            this.txtClass.Name = "txtClass";
            this.txtClass.Size = new System.Drawing.Size(58, 20);
            this.txtClass.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(343, 304);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Price";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(346, 320);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(58, 20);
            this.txtPrice.TabIndex = 13;
            // 
            // btnBuy
            // 
            this.btnBuy.Location = new System.Drawing.Point(592, 351);
            this.btnBuy.Name = "btnBuy";
            this.btnBuy.Size = new System.Drawing.Size(238, 31);
            this.btnBuy.TabIndex = 15;
            this.btnBuy.Text = "Buy Ticket";
            this.btnBuy.UseVisualStyleBackColor = true;
            this.btnBuy.Click += new System.EventHandler(this.btnBuy_Click);
            // 
            // rtxtTicket
            // 
            this.rtxtTicket.Location = new System.Drawing.Point(64, 435);
            this.rtxtTicket.Name = "rtxtTicket";
            this.rtxtTicket.Size = new System.Drawing.Size(799, 66);
            this.rtxtTicket.TabIndex = 16;
            this.rtxtTicket.Text = "";
            // 
            // lblTicket
            // 
            this.lblTicket.AutoSize = true;
            this.lblTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTicket.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblTicket.Location = new System.Drawing.Point(68, 416);
            this.lblTicket.Name = "lblTicket";
            this.lblTicket.Size = new System.Drawing.Size(126, 15);
            this.lblTicket.TabIndex = 17;
            this.lblTicket.Text = "Here is your ticket:";
            // 
            // frmSeatSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 596);
            this.Controls.Add(this.lblTicket);
            this.Controls.Add(this.rtxtTicket);
            this.Controls.Add(this.btnBuy);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.lblClass);
            this.Controls.Add(this.txtClass);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSeatSelected);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.lblFirst);
            this.Controls.Add(this.txtFirst);
            this.Controls.Add(this.lblLast);
            this.Controls.Add(this.txtLast);
            this.Controls.Add(this.dgFlight);
            this.Controls.Add(this.chkListB);
            this.Controls.Add(this.chkListA);
            this.Name = "frmSeatSelector";
            this.Text = "Buy a Ticket";
            this.Load += new System.EventHandler(this.SeatSelector_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgFlight)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox chkListA;
        private System.Windows.Forms.CheckedListBox chkListB;
        private System.Windows.Forms.DataGridView dgFlight;
        private System.Windows.Forms.TextBox txtLast;
        private System.Windows.Forms.Label lblLast;
        private System.Windows.Forms.Label lblFirst;
        private System.Windows.Forms.TextBox txtFirst;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSeatSelected;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.TextBox txtClass;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Button btnBuy;
        private System.Windows.Forms.RichTextBox rtxtTicket;
        private System.Windows.Forms.Label lblTicket;
    }
}