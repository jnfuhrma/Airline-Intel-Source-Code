﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AirlineFormApp.Helpers;
using System.IO;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace AirlineFormApp
{
    public partial class frmRegister : Form
    {
        MySqlConnection conn;
        MySqlDataAdapter daRegister;
        DataSet ds;
        string myConnStr = "server=127.0.0.1;uid=root;pwd=19PeggyAE47;database=airlines";

        public string dbConnString { get; set; }

        MySqlCommandBuilder cmdb;

        public frmRegister()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // code to check input

            if (txtPassword.Text.Length < 5)
            {
                lblPassRule.ForeColor = Color.Red;
                return;
            }
            else if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Your passwords do not match. Please correct this.");
                return;
            }
            // code to save registration
            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = this.dbConnString;
                conn.Open();
                MySqlDataAdapter daRegister = new MySqlDataAdapter();
                daRegister.SelectCommand = new MySqlCommand("select * from login where username = \"" + this.txtUser.Text + "\"", conn);
                cmdb = new MySqlCommandBuilder(daRegister);
                using (daRegister.SelectCommand)
                {
                    ds = new DataSet();
                    daRegister.Fill(ds, "login");
                    DataTable logins = ds.Tables[0];
                    if (logins.Rows.Count>0)
                    {
                        MessageBox.Show("There is already a user with this name in the database. Please choose another username", "Duplicate User Name...");
                        return;
                    }
                    var r = logins.NewRow();
                    r["username"] = this.txtUser.Text;
                    r["password"] = this.txtPassword.Text;
                    r["authority"] = "User";
                    logins.Rows.Add(r);
                }
                daRegister.Update(ds, "login");
                MessageBox.Show("Login Info Updated.", "Update");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Login Info Update  " + ex.Message);
            }

            this.Close();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text.Length < 5)
            {
                lblPassRule.ForeColor = Color.Red;
            }
            else
            {
                lblPassRule.ForeColor = Color.Black;
            }
        }

        private void frmRegister_Load(object sender, EventArgs e)
        {
            Utilities util = new Utilities();
            this.dbConnString = util.getConnectionString();
        }
    }
}
