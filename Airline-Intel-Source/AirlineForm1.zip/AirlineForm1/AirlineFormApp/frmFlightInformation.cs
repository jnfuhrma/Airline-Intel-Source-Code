﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using AirlineFormApp.Helpers;

namespace AirlineFormApp
{
    public partial class frmFlightInformation : Form
    {
        public string dbConnString { get; set; }
        MySqlConnection conn;
        MySqlDataAdapter daFlightInfo;
        DataSet ds;
        string myConnStr = "server=127.0.0.1;uid=root;pwd=19PeggyAE47;database=airlines";
        MySqlCommandBuilder cmdb;

        public frmFlightInformation()
        {
            InitializeComponent();
        }

        private void frmFlightInformation_Load(object sender, EventArgs e)
        {
            Utilities util = new Utilities();
            this.dbConnString = util.getConnectionString();

            try
            {
                conn = new MySqlConnection();
                myConnStr = "server=127.0.0.1;uid=root;pwd=19PeggyAE47;database=airlines";
                conn.ConnectionString = myConnStr;
                conn.Open();

                MySqlDataAdapter daFlightInfo = new MySqlDataAdapter();
                daFlightInfo.SelectCommand = new MySqlCommand("select * from flightInformation",conn);
                using (daFlightInfo.SelectCommand)
                {
                    
                    using (daFlightInfo)
                    {
                        ds = new DataSet();
                        daFlightInfo.Fill(ds,"flightinformation");
                        dgFlightInfo.DataSource = ds.Tables[0];
                    }
                    dgFlightInfo.Columns["id"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in creating MySql Connection: " + ex.Message);
            }
        }       

        private void dgFlightInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show("double-click Row chosen: " + e.RowIndex.ToString() + " column = " + e.ColumnIndex.ToString());
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new MySqlConnection();               
                conn.ConnectionString = myConnStr;
                conn.Open();               
                MySqlDataAdapter daFlightInfo = new MySqlDataAdapter();
                daFlightInfo.SelectCommand = new MySqlCommand("select * from flightInformation", conn);
                cmdb = new MySqlCommandBuilder(daFlightInfo);
                daFlightInfo.Update(ds, "flightinformation");
                MessageBox.Show("Flight Info Updated.", "Update");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Flight Info Update  " + ex.Message);   
            }
        }
    }


}
