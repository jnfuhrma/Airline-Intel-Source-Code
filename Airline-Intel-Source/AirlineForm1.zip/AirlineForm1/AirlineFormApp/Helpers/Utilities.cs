﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using AirlineFormApp.Models;

namespace AirlineFormApp.Helpers
{
    class Utilities
    {
        public List<Flight> loadFlightList()
        {
            List<Flight> myFlightList = new List<Flight>();
            // add a record
            Flight myFlight = new Flight();
            myFlight.flight_number = "3215";
            myFlight.passenger = 2;
            myFlight.seat_num = 4;
            myFlight.seat_row = 2;
            myFlightList.Add(myFlight);

            return myFlightList;
        }

        public List<FlightInformation> loadFlightInformation()
        {
            List<FlightInformation> flightInfoList = new List<FlightInformation>();

            FlightInformation myFlightInfo = new FlightInformation();
            myFlightInfo.id = 1;
            myFlightInfo.flight_number = "3215";
            myFlightInfo.aircraft_type = "Embraer";
            myFlightInfo.airline = "Southwest";
            myFlightInfo.first = 125.00M;
            myFlightInfo.economy = 54.00M;
            myFlightInfo.boarding = DateTime.Parse("2021-04-30 09:15");
            myFlightInfo.departure = DateTime.Parse("2021-04-30 09:55");
            myFlightInfo.arrival = DateTime.Parse("2021-04-30 10:30");
            myFlightInfo.destination = "Miami";
            myFlightInfo.origin = "Tampa";
            myFlightInfo.Gate = "D-3";
            flightInfoList.Add(myFlightInfo);

            myFlightInfo.id = 1;
            myFlightInfo.flight_number = "2550";
            myFlightInfo.aircraft_type = "Embraer";
            myFlightInfo.airline = "Southwest";
            myFlightInfo.first = 255.00M;
            myFlightInfo.economy = 92.00M;
            myFlightInfo.boarding = DateTime.Parse("2021-04-29 21:15");
            myFlightInfo.departure = DateTime.Parse("2021-04-29 21:55");
            myFlightInfo.arrival = DateTime.Parse("2021-04-29 23:30");
            myFlightInfo.destination = "Austin";
            myFlightInfo.origin = "Houston";
            myFlightInfo.Gate = "A-2";
            flightInfoList.Add(myFlightInfo);

            return flightInfoList;
        }

        public List<Login> loadLogins()
        {
            List<Login> myLogList = new List<Login>();

            Login tempLogin = new Login();
            tempLogin.UserName = "Admin";
            tempLogin.Password = "Admin";
            tempLogin.Authority = "Admin";
            myLogList.Add(tempLogin);
            return myLogList;
        }

        public string getConnectionString()
        {
            string mainPath = Directory.GetCurrentDirectory();
            StreamReader getConnString = new StreamReader(mainPath + "\\ConnectionString.txt");
            string ConnString = getConnString.ReadLine();
            getConnString.Close();
            return ConnString;
        }
    }
}
