﻿
namespace AirlineFormApp
{
    partial class frmFlightSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgFlightInfo = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgFlightInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // dgFlightInfo
            // 
            this.dgFlightInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgFlightInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFlightInfo.Location = new System.Drawing.Point(22, 50);
            this.dgFlightInfo.Name = "dgFlightInfo";
            this.dgFlightInfo.Size = new System.Drawing.Size(991, 403);
            this.dgFlightInfo.TabIndex = 0;
            this.dgFlightInfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFlightInfo_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(19, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(339, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Double-click on the row with the desired flight";
            // 
            // frmFlightSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 521);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgFlightInfo);
            this.Name = "frmFlightSelector";
            this.Text = "Flight Selector";
            this.Load += new System.EventHandler(this.frmFlightInformation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgFlightInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgFlightInfo;
        private System.Windows.Forms.Label label1;
    }
}