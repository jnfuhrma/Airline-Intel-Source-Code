﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;


namespace AirlineFormApp.Helpers
{
    class MysqlConnection
    {

        //public MysqlConnection getMysqlConn()
        //{
        //    string myConnStr;
        //    try
        //    {
        //        MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection();
        //        myConnStr = "server=127.0.0.1;uid=root;pwd=19PeggyAE47&;database=airline";

        //        conn.ConnectionString = myConnStr;
        //        conn.Open();
        //        return conn;
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error in creating MySql Connection: " + ex.Message);
        //    }

        //}
    }
}
