﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using AirlineFormApp.Models;

namespace AirlineFormApp
{
    public partial class frmFlightSelector : Form
    {
        MySqlConnection conn;
        MySqlDataAdapter daFlightInfo;
        DataSet ds;
        string myConnStr = "server=127.0.0.1;uid=root;pwd=19PeggyAE47;database=airlines";
        MySqlCommandBuilder cmdb;

        public frmFlightSelector()
        {
            InitializeComponent();
        }

        private void frmFlightInformation_Load(object sender, EventArgs e)
        {
            string myConnStr;

            try
            {
                conn = new MySqlConnection();
                myConnStr = "server=127.0.0.1;uid=root;pwd=19PeggyAE47;database=airlines";
                conn.ConnectionString = myConnStr;
                conn.Open();

                MySqlDataAdapter daFlightInfo = new MySqlDataAdapter();
                daFlightInfo.SelectCommand = new MySqlCommand("select * from flightInformation",conn);
                using (daFlightInfo.SelectCommand)
                {
                    
                    using (daFlightInfo)
                    {
                        ds = new DataSet();
                        daFlightInfo.Fill(ds,"flightinformation");
                        dgFlightInfo.DataSource = ds.Tables[0];
                    }
                    dgFlightInfo.Columns["id"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in creating MySql Connection: " + ex.Message);
            }
        }       

        private void dgFlightInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowNum = e.RowIndex;
            frmSeatSelector myseatForm = new frmSeatSelector();
            FlightInformation myFlight = new FlightInformation();
            myFlight.id = Convert.ToInt32(dgFlightInfo.Rows[rowNum].Cells[0].Value.ToString());
            myFlight.flight_number = dgFlightInfo.Rows[rowNum].Cells[1].Value.ToString();
            myFlight.airline = dgFlightInfo.Rows[rowNum].Cells[2].Value.ToString();
            myFlight.first = Convert.ToDecimal(dgFlightInfo.Rows[rowNum].Cells[3].Value.ToString());
            myFlight.economy = Convert.ToInt32(dgFlightInfo.Rows[rowNum].Cells[4].Value);      
            if( DateTime.TryParse(dgFlightInfo.Rows[rowNum].Cells[5].Value.ToString(), out DateTime outVal))
            {
                myFlight.boarding = outVal;
            }
            if (DateTime.TryParse(dgFlightInfo.Rows[rowNum].Cells[6].Value.ToString(), out DateTime outBoard))
            {
                myFlight.arrival = outBoard;
            }
            if (DateTime.TryParse(dgFlightInfo.Rows[rowNum].Cells[7].Value.ToString(), out DateTime outDep))
            {
                myFlight.departure = outDep;
            }
            myFlight.destination = dgFlightInfo.Rows[rowNum].Cells[8].Value.ToString();
            myFlight.origin = dgFlightInfo.Rows[rowNum].Cells[9].Value.ToString();
            myFlight.Gate = dgFlightInfo.Rows[rowNum].Cells[10].Value.ToString();
            myFlight.aircraft_type = dgFlightInfo.Rows[rowNum].Cells[11].Value.ToString();
            myseatForm.MySelectedFlight = myFlight;
            myseatForm.Show();
            this.Hide();           
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new MySqlConnection();               
                conn.ConnectionString = myConnStr;
                conn.Open();               
                MySqlDataAdapter daFlightInfo = new MySqlDataAdapter();
                daFlightInfo.SelectCommand = new MySqlCommand("select * from flightInformation", conn);
                cmdb = new MySqlCommandBuilder(daFlightInfo);
                daFlightInfo.Update(ds, "flightinformation");
                MessageBox.Show("Flight Info Updated.", "Update");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Flight Info Update  " + ex.Message);   
            }
        }
    }


}
