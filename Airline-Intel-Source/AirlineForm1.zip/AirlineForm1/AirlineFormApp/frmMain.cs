﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AirlineFormApp.Helpers;
using AirlineFormApp.Models;

namespace AirlineFormApp
{

    public partial class frmMain : Form
    {
        public List<Flight> ourFlight { get; set; }
        public List<FlightInformation> ourFlightInfo { get; set; }
        public string UserName { get; set; }
        public string UserAuth { get; set; }

        public frmMain()
        {
            InitializeComponent();
        }

        public void LoadNameInfo(string nameIn, string authIn)
        {
            this.UserName = nameIn;
            this.UserAuth = authIn;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            Utilities util = new Utilities();
            this.lblAuth.Text = UserAuth;
        }

        // following fulfills the delegate to update user and auth
        //public void PostUser(string userIn, string authIn)
        //{
        //    this.UserName = userIn;
        //    this.UserAuth = authIn;
        //    if (authIn == "Admin")
        //    {
        //        this.lblAuth.Text = "Admin";
        //    }
        //    else
        //    {
        //        this.lblAuth.Text = "User";
        //    }
        //}

        // followint fulfills the delegate to show the register form
        public void OpenRegister()
        {
            // Register
            frmRegister myRegister = new frmRegister();
            myRegister.ShowDialog();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            // Login
            frmLogin myLogin = new frmLogin();
            myLogin.ShowDialog();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Login
            frmLogin myLogin = new frmLogin();
            myLogin.ShowDialog();
        }

        private void btnShowFlightInfo_Click(object sender, EventArgs e)
        {
            if (this.UserAuth == "Admin")
            {
                frmFlightInformation myFlightInfo = new frmFlightInformation();
                myFlightInfo.ShowDialog();
            }
            else
            {
                frmFlightSelector myFlightSel = new frmFlightSelector();
                myFlightSel.ShowDialog();
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
