﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using AirlineFormApp.Models;
using AirlineFormApp.Helpers;

namespace AirlineFormApp
{
    public partial class frmSeatSelector : Form
    {
        MySqlConnection conn;
        MySqlDataAdapter daTicket;
        DataSet ds;
        MySqlCommandBuilder cmdb;

        public FlightInformation MySelectedFlight { get; set; }
        public string dbConnString { get; set; }
        enum seatID { A, B, C, D }
        string[,] seatsArray = new string[10, 2];

        public frmSeatSelector()
        {
            InitializeComponent();
        }

        private void SeatSelector_Load(object sender, EventArgs e)
        {
            Utilities util = new Utilities();
            this.dbConnString = util.getConnectionString();

            List<FlightInformation> myFlightInfoList = new List<FlightInformation>();
            myFlightInfoList.Add(this.MySelectedFlight);
            dgFlight.DataSource = myFlightInfoList;

            // load seat array
            for (int i = 0; i < seatsArray.GetLength(0); i++)
            {
                for (int j = 0; j < seatsArray.GetLength(1); j++)
                {
                    seatsArray[i, j] = Enum.GetName(typeof(seatID), j);
                }
            }

            // get occupied seats
            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection();
            conn.ConnectionString = this.dbConnString;
            conn.Open();

            using (MySqlCommand cmd = new MySqlCommand("getUsedSeats", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flight_numIn", this.MySelectedFlight.flight_number);
                using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow dtRow in dt.Rows)
                        {
                            seatsArray[(int)dtRow[1], (int)dtRow[2]] = "X-X";
                        }
                    }
                }
            }
            // load checklists - A seats
            for (int i = 0; i < seatsArray.GetLength(0); i++)
            {
                chkListA.Items.Add(seatsArray[i, 0] + "-" + (i + 1).ToString());
            }

            for (int j = 0; j < seatsArray.GetLength(0); j++)
            {
                chkListB.Items.Add(seatsArray[j, 1] + "-" + (j + 1).ToString());
            }
        }

        private void chkListA_SelectedIndexChanged(object sender, EventArgs e)
        {
            // MessageBox.Show("Seat selected is: " + chkListA.SelectedItem.ToString());

            if (chkListA.SelectedItem.ToString().Substring(0, 1) == "X")
            {
                MessageBox.Show("That seat is occupied. Please select another.");
                return;
            }
            this.txtSeatSelected.Text = chkListA.SelectedItem.ToString();


            int selIndex = chkListA.SelectedIndex;
            if (selIndex < 4)
            {
                this.txtClass.Text = "First";
                this.txtPrice.Text = this.MySelectedFlight.first.ToString();
            }
            else
            {
                this.txtClass.Text = "Economy";
                this.txtPrice.Text = this.MySelectedFlight.economy.ToString();
            }
        }     

        private void btnBuy_Click(object sender, EventArgs e)
        {
            // check the data:
            if (this.txtLast.Text=="")
            {
                MessageBox.Show("Please enter your last name.");
                return;
            }
            if (this.txtFirst.Text == "")
            {
                MessageBox.Show("Please enter your first name.");
                return;
            }
            if (this.txtAge.Text == "")
            {
                MessageBox.Show("Please enter your first age.");
                return;
            }
            if (this.txtSeatSelected.Text == "")
            {
                MessageBox.Show("Please select a seat.");
                return;
            }

            // load the ticket object from the form
            Ticket myTicket = new Ticket();
            myTicket.flight_number = this.MySelectedFlight.flight_number;
            myTicket.passenger_last = this.txtLast.Text;
            myTicket.passenger_first = this.txtFirst.Text;
            myTicket.ticket_class = this.txtClass.Text;
            myTicket.price = Convert.ToDecimal(this.txtPrice.Text);
            myTicket.departure = (DateTime)this.MySelectedFlight.departure;
            myTicket.arrival = (DateTime)this.MySelectedFlight.arrival;
            myTicket.origin = this.MySelectedFlight.origin;
            myTicket.destination = this.MySelectedFlight.destination;
            myTicket.gate = this.MySelectedFlight.Gate;
            myTicket.seat_row = Convert.ToInt32(this.txtSeatSelected.Text.Substring(2, 1)) - 1;
            myTicket.seat_col = (int)Enum.Parse(typeof(seatID), this.txtSeatSelected.Text.Substring(0, 1));

            // code to save Ticket
            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = this.dbConnString;
                conn.Open();
                MySqlDataAdapter daTicket = new MySqlDataAdapter();
                daTicket.SelectCommand = new MySqlCommand("select * from tickets", conn);
                cmdb = new MySqlCommandBuilder(daTicket);
                using (daTicket.SelectCommand)
                {
                    ds = new DataSet();
                    daTicket.Fill(ds, "tickets");
                    DataTable tickets = ds.Tables[0];

                    var r = tickets.NewRow();
                    r["flight_number"] = myTicket.flight_number;
                    r["passenger_last"] = myTicket.passenger_last;
                    r["passenger_first"] = myTicket.passenger_first;
                    r["ticket_class"] = myTicket.ticket_class;
                    r["price"] = myTicket.price;
                    r["departure"] = myTicket.departure;
                    r["arrival"] = myTicket.arrival;
                    r["origin"] = myTicket.origin;
                    r["destination"] = myTicket.destination;
                    r["gate"] = myTicket.gate;
                    r["seat_row"] = myTicket.seat_row;
                    r["seat_col"] = myTicket.seat_col;
                    tickets.Rows.Add(r);
                }
                daTicket.Update(ds, "tickets");
                MessageBox.Show("Ticket table Updated.", "Update");
                StringBuilder sbTicket = new StringBuilder();
                sbTicket.Append("Flight: ");
                sbTicket.Append(myTicket.flight_number);
                sbTicket.Append("      From: ");
                sbTicket.Append(myTicket.origin);
                sbTicket.Append("      To: ");
                sbTicket.Append(myTicket.destination);
                sbTicket.Append("\r\n");
                sbTicket.Append("        Departure: ");
                sbTicket.Append(myTicket.departure.ToString());
                sbTicket.Append("         Arrival:  ");
                sbTicket.Append(myTicket.arrival.ToString());
                sbTicket.Append("\r\n");
                sbTicket.Append("Passenger:   ");
                sbTicket.Append(myTicket.passenger_first + " ");
                sbTicket.Append(myTicket.passenger_last);
                sbTicket.Append("       Seat:  ");
                sbTicket.Append(this.txtSeatSelected.Text);
                sbTicket.Append("          Class: ");
                sbTicket.Append(myTicket.ticket_class);
                sbTicket.Append("     Price: ");
                sbTicket.Append(myTicket.price.ToString());
                this.rtxtTicket.Text = sbTicket.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in making Ticket: " + ex.Message);
            }

        }

        private void chkListB_SelectedIndexChanged(object sender, EventArgs e)
        {
            // MessageBox.Show("Seat selected is: " + chkListB.SelectedItem.ToString());

            if (chkListB.SelectedItem.ToString().Substring(0, 1) == "X")
            {
                MessageBox.Show("That seat is occupied. Please select another.");
                return;
            }
            this.txtSeatSelected.Text = chkListB.SelectedItem.ToString();


            int selIndex = chkListB.SelectedIndex;
            if (selIndex < 4)
            {
                this.txtClass.Text = "First";
                this.txtPrice.Text = this.MySelectedFlight.first.ToString();
            }
            else
            {
                this.txtClass.Text = "Economy";
                this.txtPrice.Text = this.MySelectedFlight.economy.ToString();
            }
        }
    }
}
